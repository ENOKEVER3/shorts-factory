"""Compose the final vertical Short with ffmpeg only (no paid APIs).

Background: procedurally generated animation (5 styles x 6 palettes, rotated).
Overlay: per-sentence illustrations, progress bar + burned-in captions. Audio: narration + generated ambient pad.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from .util import ROOT, log, run

PALETTES = [
    ("0x050816", "0x0e7490", "0x22d3ee", "0x1e1b4b"),
    ("0x0a0a0a", "0x14532d", "0xa3e635", "0x052e16"),
    ("0x0c0a09", "0x7c2d12", "0xfb923c", "0x1c1917"),
    ("0x020617", "0x1d4ed8", "0x38bdf8", "0x0f172a"),
    ("0x0b0f19", "0x9f1239", "0xf43f5e", "0x111827"),
    ("0x04130f", "0x0f766e", "0x5eead4", "0x022c22"),
]
CHORDS = [(110.0, 164.81, 220.0), (130.81, 196.0, 261.63), (98.0, 146.83, 196.0), (87.31, 130.81, 174.61)]


def _hex_rgb(h: str) -> tuple[int, int, int]:
    v = int(h, 16)
    return (v >> 16) & 255, (v >> 8) & 255, v & 255


def background_filter(style: int, pal: tuple[str, ...], d: float, w: int, h: int, fps: int) -> str:
    c0, c1, c2, c3 = pal
    finish = f"scale={w}:{h}:flags=lanczos,format=yuv420p"
    kind = style % 5
    if kind in (0, 1, 2):
        gtype = ["spiral", "radial", "linear"][kind]
        return (
            f"gradients=s={w // 2}x{h // 2}:r={fps}:d={d:.2f}:speed=0.012:n=4:type={gtype}:"
            f"c0={c0}:c1={c1}:c2={c2}:c3={c3},drawgrid=w=36:h=36:t=1:c=white@0.07,{finish},"
            f"eq=brightness=-0.06:saturation=1.15,vignette=PI/4.5"
        )
    if kind == 3:
        return (
            f"life=s=270x480:r={fps}:mold=12:ratio=0.10:life_color={c2}:death_color={c0}:mold_color={c1},"
            f"scale={w}:{h}:flags=neighbor,gblur=sigma=2,eq=brightness=-0.12,format=yuv420p,vignette=PI/4"
        )
    r0, g0, b0 = _hex_rgb(c1)
    r1, g1, b1 = _hex_rgb(c2)
    wave_ = "(0.5+0.25*sin(X/13+T*1.1)+0.25*sin(hypot(X-108,Y-192)/15-T*1.2))"
    return (
        f"nullsrc=s=216x384:r={fps}:d={d:.2f},format=rgb24,"
        f"geq=r='{r0}*0.35+({r1}-{r0}*0.35)*{wave_}*0.7':g='{g0}*0.35+({g1}-{g0}*0.35)*{wave_}*0.7':"
        f"b='{b0}*0.35+({b1}-{b0}*0.35)*{wave_}*0.7',drawgrid=w=18:h=18:t=1:c=white@0.06,{finish},vignette=PI/4"
    )


FULL_W, FULL_H = 1080, 1920  # pictures fill the whole vertical screen (no floating square card)


CAMERA_MOVES = ("push-in", "pull-out", "pan-right", "pan-left", "drift-up")


def camera_move(n: int, frames: int) -> str:
    """Zoompan expression for scene n: rotating Ken Burns moves so consecutive scenes never move alike."""
    t = f"(on/{frames})"
    ease = f"(0.5-0.5*cos(PI*{t}))"  # smooth start and stop
    cx, cy = "iw/2-(iw/zoom/2)", "ih/2-(ih/zoom/2)"
    move = CAMERA_MOVES[n % len(CAMERA_MOVES)]
    if move == "push-in":
        return f"z='1.0+0.14*{ease}':x='{cx}':y='{cy}'"
    if move == "pull-out":
        return f"z='1.14-0.14*{ease}':x='{cx}':y='{cy}'"
    if move == "pan-right":
        return f"z='1.12':x='(iw-iw/zoom)*{ease}':y='{cy}'"
    if move == "pan-left":
        return f"z='1.12':x='(iw-iw/zoom)*(1-{ease})':y='{cy}'"
    return f"z='1.12':x='{cx}':y='(ih-ih/zoom)*(1-{ease})'"


def illustration_chain(segs, pal: tuple[str, ...], fps: int, first_input: int = 1) -> tuple[str, str]:
    """Filters that slide each illustration in with a slow zoom. Returns (filters, last label)."""
    parts, last = [], "bg"
    for n, (p, start, end) in enumerate(segs):
        dur = end - start
        frames = max(int(dur * fps), 2)
        fade = min(0.3, dur / 4)
        if str(p).endswith(".mp4"):  # pre-animated orbital scene: no Ken Burns, just fade in/out
            parts.append(
                f"[{first_input + n}:v]scale={FULL_W}:{FULL_H}:flags=lanczos,fps={fps},format=yuva420p,"
                f"fade=t=in:st=0:d={fade:.2f}:alpha=1,fade=t=out:st={dur - fade:.2f}:d={fade:.2f}:alpha=1,"
                f"setpts=PTS-STARTPTS+{start:.3f}/TB[im{n}]"
            )
            parts.append(f"[{last}][im{n}]overlay=x=0:y=0:eof_action=pass[ov{n}]")
            last = f"ov{n}"
            continue
        parts.append(
            f"[{first_input + n}:v]scale=1620:2880:force_original_aspect_ratio=increase:flags=lanczos,crop=1620:2880,"
            f"zoompan={camera_move(n, frames)}:d={frames}:s={FULL_W}x{FULL_H}:fps={fps},unsharp=5:5:0.6,"
            f"eq=brightness=-0.04:contrast=1.06:saturation=1.12,vignette=PI/5,"
            f"format=yuva420p,fade=t=in:st=0:d={fade:.2f}:alpha=1,fade=t=out:st={dur - fade:.2f}:d={fade:.2f}:alpha=1,"
            f"setpts=PTS-STARTPTS+{start:.3f}/TB[im{n}]"
        )
        nxt = f"ov{n}"
        parts.append(f"[{last}][im{n}]overlay=x=0:y=0:eof_action=pass[{nxt}]")
        last = nxt
    return ";".join(parts), last


def render(narration: Path, ass: Path, out: Path, index: int, cfg: dict, total: float, segs=()) -> Path:
    v = cfg["video"]
    w, h, fps = v["width"], v["height"], v["fps"]
    pal = PALETTES[index % len(PALETTES)]
    work = ass.parent
    fonts = work / "fonts"
    if not fonts.exists():
        shutil.copytree(ROOT / "assets" / "fonts", fonts)

    bg = background_filter(index, pal, total, w, h, fps)
    ill, base = illustration_chain(list(segs), pal, fps)
    vf = (
        f"{bg}[bg];{ill + ';' if ill else ''}color=c={pal[2]}:s={w}x14:r={fps}:d={total:.2f}[bar];"
        f"[{base}][bar]overlay=x='-w+w*t/{total:.2f}':y=H-14:shortest=1,ass={ass.name}:fontsdir=fonts[v]"
    )
    if cfg.get("music", True):
        f1, f2, f3 = CHORDS[index % len(CHORDS)]
        # Cinematic bed: sub-bass drone + slow-swelling chord pad + airy shimmer, then the music
        # ducks under the narrator (sidechain) and blooms in the pauses.
        pad = (
            f"aevalsrc='0.35*sin(2*PI*{f1 / 2}*t)+0.22*sin(2*PI*{f1}*t)*(0.6+0.4*sin(2*PI*0.05*t))"
            f"+0.18*sin(2*PI*{f2}*t)*(0.5+0.5*sin(2*PI*0.07*t+1))+0.15*sin(2*PI*{f3}*t)*(0.5+0.5*sin(2*PI*0.09*t+2))"
            f"+0.05*sin(2*PI*{f3 * 2}*t)*(0.5+0.5*sin(2*PI*0.31*t))':s=44100:d={total:.2f},"
            f"lowpass=f=1400,aecho=0.8:0.7:420|780:0.35|0.22,"
            f"afade=t=in:d=2.5,afade=t=out:st={max(total - 2.5, 0):.2f}:d=2.5,volume=0.22[pad];"
            f"[0:a]apad=whole_dur={total:.2f},highpass=f=70,acompressor=threshold=0.12:ratio=3:attack=5:release=120,"
            f"volume=1.15,asplit=2[nar][key];"
            f"[pad][key]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=450[duck];"
            f"[nar][duck]amix=inputs=2:duration=first:normalize=0,loudnorm=I=-14:TP=-1.0:LRA=9,alimiter=limit=0.95[a]"
        )
    else:
        pad = f"[0:a]apad=whole_dur={total:.2f},highpass=f=70,loudnorm=I=-14:TP=-1.0:LRA=9[a]"

    log(f"Rendering {total:.1f}s video (background style {index % 5}, palette {index % len(PALETTES)})")
    run(
        [
            "ffmpeg", "-y", "-v", "error", "-i", str(narration.resolve()),
            *[a for p, _s, _e in segs for a in ("-i", str(Path(p).resolve()))],
            "-filter_complex", f"{vf};{pad}",
            "-map", "[v]", "-map", "[a]", "-t", f"{total:.2f}",
            "-c:v", "libx264", "-preset", cfg["video"].get("preset", "fast"), "-crf", str(cfg["video"].get("crf", 17)), "-profile:v", "high", "-level", "4.2",
            "-tune", "film", "-maxrate", "16M", "-bufsize", "32M", "-g", str(fps * 2), "-pix_fmt", "yuv420p", "-r", str(fps),
            "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
            "-c:a", "aac", "-b:a", "320k", "-ar", "48000", "-movflags", "+faststart", str(out.resolve()),
        ],
        cwd=work,
    )
    return out
